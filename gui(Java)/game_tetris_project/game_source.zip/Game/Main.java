package Game;

public class Main {
    public static void main(String[] args) {
        TetrisGame tetris = new TetrisGame();
    }
}
