from itertools import groupby
from Vector import Vector

class FileReader:
    def __init__(self,filePath):
        self.__filePath = filePath
        f = open(self.__filePath, "r", encoding="utf-8")
        lines = [[j.replace("\n", "") for j in i.split(";")] for i in f.readlines() if i != "\n" and i != ""]
        self.__mapVectors = [(key,[Vector([float(j) for j in i[:-1]]) for i in list(group)]) for key, group in groupby(lines,lambda x: x[-1])]
    def getMapVectors(self):
        return self.__mapVectors
    def getListVectors(self):
        return sum([[(i[0], j) for j in i[1]] for i in self.getMapVectors()], [])
