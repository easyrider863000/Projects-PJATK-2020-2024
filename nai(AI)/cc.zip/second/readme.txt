Params should be provided in console.
First parameter "a".
Second parameter "train-set".
Third parameter "test-set".
Example for execute program from command-line: "python main.py 0.1 train-set.csv test-set.csv".
